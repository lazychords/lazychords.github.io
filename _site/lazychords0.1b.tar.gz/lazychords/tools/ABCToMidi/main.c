#include "abc.h"
#include "parseabc.h"

int main(int argc, char**argv)
{
    convert(argv[1]);
    return 0;
}
