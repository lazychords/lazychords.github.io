/**
 * @file   Observation.hpp
 * @date   Thu Oct  9 22:32:21 2014
 * 
 * @brief  This file contains the descriptions of what can be observation types. Each observation class should include a static member describing its id (and each ID should be unique).
 * 
 * 
 */
#ifndef OBSERVATION_HPP_INCLUDED
#define OBSERVATION_HPP_INCLUDED
#include "Markov.hpp"
#include "Music.hpp"
#include <iostream>




class ObsMeasure : private Measure
{
public:
    /** @brief Construction from a measure
     * 
     * @param M The measure from which the observation must be deduced
     */
    ObsMeasure(const Measure & M);
    /**@brief Default constructor
     * 
     * 
     */

    ObsMeasure();

    friend std::ostream & operator<<(std::ostream& os, const ObsMeasure &m);
    
    /**@brief Compute the closest observation 
     * 
     * Given a set of known observation, this function has to find
     * the closest match, if not an exact match
     * @param m The map giving the known observations and their corresponding Ids
     * 
     * @return The id of the selected observation.

     */
    HMM::ObsId getClosestObs(const std::vector<ObsMeasure> &m);

    const static int TypeID = 0; ///< Mandatory id of the class (must be unique amongst Observation classes)
    

};




/**@brief An observation class based on statitistics of presence of the notes.
 * We compute a the percentage each note appears in the measure. As a distance, we use
 * the distance induced by the infinite norm on these vectors of percentage.
 */

class ObsPresenceStats : private Measure
{
public:
    /** @brief Construction from a measure
     * 
     * @param M The measure from which the observation must be deduced
     */
    ObsPresenceStats(const Measure & M,double grain);


    friend std::ostream & operator<<(std::ostream& os, const ObsPresenceStats &m);

    bool operator==(const ObsPresenceStats& o) const __attribute__((pure));
    
    /**@brief Compute the closest observation 
     * 
     * Given a set of known observation, this function has to find
     * the closest match, if not an exact match. The distance used is based on the infinite norm.
     * @param m The vector giving the known observations
     * 
     * @return The id of the selected observation.

     */
    HMM::ObsId getClosestObs(const std::vector<ObsPresenceStats> &m) const __attribute__((pure));

    const static int TypeID = 1; ///< Mandatory id of the class (must be unique amongst Observation classes)
    
protected:
    
    /** @brief Compute distance from other observation
     * 
     * 
     * @param other the other observation
     * @return the distance (according to infinite norm)
     */
    double distanceFrom(const ObsPresenceStats &other) const __attribute__((pure));

    
private:
    std::vector<double> m_stats; ///< Vector of 12 elements (one for each different possible note) containing the fraction of the measure each note is being played
    double m_grain;
    

};
 

#endif
