#include "Observation.hpp"


using namespace std;

unsigned intOfCNN(const CompleteNoteName& cn) __attribute__((const));

unsigned intOfCNN(const CompleteNoteName& cn){
    if(cn==CompleteNoteName(NoteName::C,Accidental::None)){
        return 0;
    }
    if(cn==CompleteNoteName(NoteName::C,Accidental::Sharp)){
        return 1;
    }
    if(cn==CompleteNoteName(NoteName::D,Accidental::None)){
        return 2;
    }
    if(cn==CompleteNoteName(NoteName::D,Accidental::Sharp)){
        return 3;
    }
    if(cn==CompleteNoteName(NoteName::E,Accidental::None)){
        return 4;
    }
    if(cn==CompleteNoteName(NoteName::F,Accidental::None)){
        return 5;
    }
    if(cn==CompleteNoteName(NoteName::F,Accidental::Sharp)){
        return 6;
    }
    if(cn==CompleteNoteName(NoteName::G,Accidental::None)){
        return 7;
    }
    if(cn==CompleteNoteName(NoteName::G,Accidental::Sharp)){
        return 8;
    }
    if(cn==CompleteNoteName(NoteName::A,Accidental::None)){
        return 9;
    }
    if(cn==CompleteNoteName(NoteName::A,Accidental::Sharp)){
        return 10;
    }
    if(cn==CompleteNoteName(NoteName::B,Accidental::None)){
        return 11;
    }
    assert(false); //should never happen
    return 0; 
}


ObsPresenceStats::ObsPresenceStats(const Measure & M,double grain) : m_stats(vector<double>(12,0)),m_grain(grain)
{
    for(const auto & note : M){
        m_stats[intOfCNN(CompleteNoteName(note.second.m_name,note.second.m_modifier))]+=boost::rational_cast<double>(note.second.m_duration) / (double)M.getDuration();
    }
}

std::ostream & operator<<(std::ostream& os, const ObsPresenceStats &o)
{
    os<<o.m_stats.size()<<endl;
    for(unsigned i = 0;i<o.m_stats.size();i++){
        os<<o.m_stats[i]<<" ";
    }
    os<<endl;
    return os;
}

bool ObsPresenceStats::operator==(const ObsPresenceStats& o) const
{
    return distanceFrom(o)<=m_grain;
}

double ObsPresenceStats::distanceFrom(const ObsPresenceStats &other) const
{
    assert(m_stats.size()==other.m_stats.size());
    assert(m_stats.size()==12);
    double res = 0;
    for(unsigned i = 0;i<12;i++){
        res += abs(other.m_stats[i] - m_stats[i]);
    }
    return res;
}


HMM::ObsId ObsPresenceStats::getClosestObs(const std::vector<ObsPresenceStats> &m) const
{
    double closestDist=1e9;
    unsigned closestId = 0;
    unsigned i = 0;
    for(const auto & o:m){
        double d = distanceFrom(o);
        if(d<closestDist){
            closestDist = d;
            closestId = i;
        }
        i++;
    }
    return closestId;
}
