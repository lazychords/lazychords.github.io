/**
 * @file   Markov.hpp
 * @date   Mon Oct  6 02:53:45 2014
 *
 * @brief  This file describes the data structures used to represent a hidden Markov model (HMM)
 *
 *
 */

#ifndef MARKOV_HPP_INCLUDED
#define MARKOV_HPP_INCLUDED

#include "Music.hpp"
#include "Traits.hpp"
#include "Database.hpp"
#include <vector>
#include <map>
#include <exception>
#include <string>
#include <iostream>
#include <boost/type_traits.hpp>
#include <boost/rational.hpp>


/** @brief Unified interface for HMMs, independant of the observation type
 *
 *
 */

class HMM
{
public:
    friend HMM*  loadFromFile(std::string fname);    
    /** @brief Return a list of chord progressions with scores.
     *
     * Scores are non negative.
     * It is guaranted that at least one progression has a score different than 0.
     *
     * @param n Number of chord progressions wanted (n > 0 )
     * @throw std::domain_error If the number of chords requested is higher than what can be generated, an exception is thrown
     * @return A list of n chord progressions, along with their scores, in decreasing order.
     */
     using Proba = double;
    using ObsId = unsigned;
    using StateId = unsigned;
    using Score = double;
    //using Proba = boost::rational<int>;
    //using Score = boost::rational<int>;
    
    virtual ~HMM() {};
    
    /** @brief Return a list of chord progressions with scores.
     *
     * Scores are non negative.
     * It is guaranted that at least one progression has a score different than 0.
     *
     * @param M Observed melody from which we want to generate chords
     * @param n Number of chord progressions wanted (n > 0 )
     * @throw std::domain_error If the number of chords requested is higher than what can be generated, an exception is thrown
     * @return A list of n chord progressions, along with their scores, in decreasing order.
     */
    virtual std::vector<std::pair<ChordProgression,Score> > getBestProgressions(Melody M, unsigned n =1) const = 0;


    /** Return the maximal number of distinct progressions that can be generated
     *
     * @return a non negative integer, the maximal number of progressions
     */
    virtual unsigned getMaxProgressionsNbr() const = 0;

    /**@brief Save the class to a given file
     * 
     * 
     * @param fname Name of the target file
     */
    virtual void saveToFile(const std::string & fname) const = 0;


    virtual void learn(Database& db, const std::string& style) = 0;

protected:

};


#include "Observation.hpp"

CREATE_MEMBER_DETECTOR(getClosestObs) //macro that generates a trait has_getClosestObs<> that checks for the implementation of the public method "getClosestObs"
CREATE_STATIC_MEMBER_DETECTOR(TypeID)

template <class Obs>
class HMM_backend;

/** @brief Backend for a Hidden Markov Model object, templated over the observation type
 *
 * The parameter of the template correspond to the Observation type. We can imagine several ways to describe these,
 * for example with meta datas rather than plain music description
 */

template <class Obs>
class HMM_backend : public HMM
{
    static_assert(boost::has_left_shift<std::ostream,Obs>::value,"error : the template argument Obs must provide a stream operator to ostream"); //ensure that the template class can be printed to ostream
    static_assert(function_traits::has_TypeID<Obs>::value,"error : the template argument Obs must provide a static member describing its type id");
    static_assert(function_traits::has_getClosestObs<Obs,HMM::ObsId(const std::vector<Obs>&)>::value,"error : the template argument must provide a public getClosestObs method of type std::vector<Obs> -> ObsId");
public :
    class State
    {
    public :
        friend class HMM_backend;
        Chord m_c; ///< Description of the chord
        unsigned m_position; ///<Position of the chord in the progression (rank, between 1 and 4)
    private :
        State(const Chord & c,unsigned p,unsigned id) : m_c(c),m_position(p),m_stateID(id){}
        unsigned m_stateID;
        operator unsigned() const{return m_stateID;};///returns stateID
    };

    HMM_backend();
    ~HMM_backend(){};
    /** @brief Return a list of chord progressions with scores.
     *
     * Scores are non negative.
     * It is guaranted that at least one progression has a score different than 0.
     *
     * @param M Observed melody from which we want to generate chords
     * @param n Number of chord progressions wanted (n > 0 )
     * @throw std::domain_error If the number of chords requested is higher than what can be generated, an exception is thrown
     * @return A list of n chord progressions, along with their scores, in decreasing order.
     */
    std::vector<std::pair<ChordProgression,Score> > getBestProgressions(Melody M, unsigned n =1) const;

    /** Return the maximal number of distinct progressions that can be generated
     *
     * @return a non negative integer, the maximal number of progressions
     */
    unsigned getMaxProgressionsNbr() const __attribute__((const));

    /**@brief Save the class to a given file
     * 
     * 
     * @param fname Name of the target file
     */
    void saveToFile(const std::string & fname) const;



    void learn(Database& db, const std::string& style);
    void learn_unsupervised(Database& db, const std::string& style);

protected:
    void forwardProcedure(const std::vector<Obs> & o);
    void backwardProcedure(const std::vector<Obs> & o);
    void updateProcedure(const std::vector<Obs> & o);
    void generateObsSet(const std::vector<Data>& entries);

private :
    std::vector<Proba> m_pi; ///< Initial distribution vector
    std::vector<State> m_states; ///< List of hidden states
    std::vector<std::vector<Proba> > m_transition; ///< Probability transition matrix (m_transition[i][j] is the probability of going from State i to State j)
    std::vector<std::vector<Proba> > m_observation; ///< Observation probability matrix (m_observation[i][j] is the probability of observing Obs j from State i)
    std::vector<Obs> m_obsSet; ///< Description of each observation

    std::vector<std::vector<Proba>> m_alpha; // used for forward procedure
    std::vector<std::vector<Proba>> m_beta; // used for backward procedure
};


/** @brief Load the HMM from a given file.
 *
 * Be careful, this function erase all the existing data of the class
 * @param fname Name of the file
 */
HMM * loadFromFile(std::string fname);

#include "Markov.cpp"
#endif // MARKOV_HPP_INCLUDED
