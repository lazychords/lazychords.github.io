#include <fstream>
#include <algorithm>
#include <climits>
using namespace std;


#define GET_BEST_PROGRESSION_DEBUG
#define FORWARD_PROCEDURE_DEBUG
#define BACKWARD_PROCEDURE_DEBUG


template <class Obs>
HMM_backend<Obs>::HMM_backend() :
    m_pi(),m_states(),m_transition(),m_observation(),m_obsSet(),m_alpha(),m_beta()
{
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wmissing-braces"
    static const array<Chord::SeventhType,4> availableSeventh {Chord::SeventhType::None,Chord::SeventhType::Minor,Chord::SeventhType::Major,Chord::SeventhType::Dim};
    static const array<Chord::ChordType,6> availableChords  {Chord::ChordType::Major,Chord::ChordType::Minor,Chord::ChordType::Dim,Chord::ChordType::Aug,Chord::ChordType::Sus4,Chord::ChordType::Sus2};
    #pragma GCC diagnostic pop
    unsigned i = 0;
    for(Pitch p(CompleteNoteName(NoteName::C,Accidental::None),4);p.m_octave==4;p+=1){
        for(const auto & s : availableSeventh){
            for(const auto & c : availableChords){
                for(unsigned rank=1;rank<=4;rank++){
                    m_states.push_back(State(Chord(Fraction(4),CompleteNoteName(p.m_name,p.m_modifier),s,c),rank,i));
                    i++;
                }
            }
        }
    }
    m_transition = std::move(std::vector<std::vector<Proba> >(i,std::vector<Proba>(i,0)));
    m_observation = std::move(std::vector<std::vector<Proba> >(i));
    m_pi = std::move(std::vector<Proba>(i,0));
}
template <class Obs>
void HMM_backend<Obs>::saveToFile(const string & fname) const
{
    ofstream file(fname,ios::out | ios::trunc);
    if(file){
        file<<Obs::TypeID<<endl;
        file<<m_obsSet.size()<<endl;
        for(auto p : m_obsSet){
            cout<<p<<endl;
        }
        file<<m_states.size()<<endl;
        for(const auto& s : m_states){
            file<<s.m_c<<" "<<s.m_position<<endl;
        }
        file<<m_transition.size()<<" "<<(m_transition.size()>0 ? 0 : m_transition[0].size())<<endl;
        for(unsigned i=0;i<m_transition.size();i++){
            for(unsigned j=0;j<m_transition[0].size();j++){
                file<<m_transition[i][j]<<" ";
            }
            file<<endl;
        }
        file<<m_observation.size()<<" "<<(m_observation.size()>0 ? 0 : m_observation[0].size())<<endl;
        for(unsigned i=0;i<m_observation.size();i++){
            for(unsigned j=0;j<m_observation[0].size();j++){
                file<<m_observation[i][j]<<" ";
            }
            file<<endl;
        }
        for(const auto & p: m_pi){
            file<<p<<endl;
        }

    }else{
        cerr<<"Error opening file"<<endl;
    }
}


/* Auxiliary procedure ;
 * returns a sorted vector containing the values of parameter array, each value alongside with its coordinates
 * in the original 2D vector */
inline std::vector<std::pair<HMM::Proba,std::pair<unsigned,unsigned> > > findBests(const std::vector<std::vector<HMM::Proba> >  &array)  __attribute__((const));

inline std::vector<std::pair<HMM::Proba,std::pair<unsigned,unsigned> > > findBests(const std::vector<std::vector<HMM::Proba> >  &array)
{
    std::vector<std::pair<HMM::Proba,std::pair<unsigned,unsigned> > > res;
    for(unsigned i = 0;i<array.size();i++){
        for(unsigned j = 0;j<array[i].size();j++){
            res.push_back(make_pair(array[i][j],make_pair(i,j)));
        }
    }
    sort(res.begin(),res.end(), [](const std::pair<HMM::Proba,std::pair<unsigned,unsigned> > &p1, const std::pair<HMM::Proba,std::pair<unsigned,unsigned> > &p2){return p1.first>p2.first;});

    return res;
}


template<typename Obs>
std::vector<std::pair<ChordProgression,HMM::Score> > HMM_backend<Obs>::getBestProgressions(Melody M, unsigned n) const
{
#ifdef GET_BEST_PROGRESSION_DEBUG
    cout << "getBestProgression function, from Markov.cpp" << endl;
    cout << "Input : " << "Melody " << M << "Number " << n << endl; 
#endif

    std::vector<ObsId> observations(M.size());
    std::transform(M.begin(),M.end(),observations.begin(), [this](const Measure &Mes){return Obs(Mes,0.2).getClosestObs(m_obsSet);});

    std::vector<std::pair<ChordProgression,Score> > result (n,std::pair<ChordProgression,Score>());
    vector<vector<vector<pair<Proba,pair<unsigned,unsigned>>>>> table (
                                                                       observations.size(),
                                                                       vector<vector<pair<Proba,pair<unsigned,unsigned>>>> (
                                                                                                                            m_states.size(),
                                                                                                                            vector<pair<Proba,pair<unsigned,unsigned>>>(
                                                                                                                                                                         n,
                                                                                                                                                                         pair<Proba,pair<unsigned,unsigned> > ()))); // for dynamic programming

    // Initialisation of table
    for(auto c : m_states)
    {
        for(unsigned j=0;j<n;j++)
        {
            table[0][c][j].first = m_pi[c] * m_observation[c][observations[0]];
            table[0][c][j].second = make_pair(INT_MAX,INT_MAX);
        }
    }

    // Filling the table
    for(unsigned i=1;i<observations.size();i++)
    {
        for(const auto &c : m_states)
        {
            std::vector<std::vector<Proba> > temp (m_states.size(),std::vector<Proba> (n, HMM::Proba(0)));
            for(unsigned j=0;j<n;j++)
            {
               for(const auto &cprime : m_states)
                {
                    temp[cprime][j] = m_transition[cprime][c] * m_observation[c][observations[i]] * table[i-1][cprime][j].first;
                }
            }

            std::vector<std::pair<Proba,std::pair<unsigned,unsigned> > > classement = findBests(temp);
            for (unsigned j=0;j<n;j++)
            {
                table[i][c][j] = classement[j];
            }
        }
    }

    // Finding the last states of the n most probable sequences
    std::vector<std::vector<Proba> > temp (m_states.size(), std::vector<Proba> (n,Proba ()));
    for(const auto &c : m_states)
    {
        for(unsigned j=0;j<n;j++)
        {
            temp[c][j] = table[observations.size()-1][c][j].first;
        }
    }
    std::vector<std::pair<Proba,std::pair<unsigned,unsigned> > >  classement = findBests(temp);

    // Backtracking
    for(unsigned j=0;j<n;j++)
    {
        std::pair<Proba,std::pair<unsigned,unsigned> > maximum = table[observations.size()-1][classement[j].second.first][classement[j].second.second];
        result[j].second = (Score) maximum.first; // possible future type problem (Proba -> Score)
        //result[j].first.push_back(classement[j].second.first);
        result[j].first.push_back(m_states[classement[j].second.first].m_c);
        /*
?????
This instruction is basicaly
    ChordProgression.push_back(stateID);
but it should be
    ChordProgression.push_back(Chord);
so we need a function stateID->Chord
don't we?   
?????
*/
        for(int i=(int)observations.size()-(int)2;i>=0;i--)
        {
            //result[j].first.push_back(maximum.second.first);
            result[j].first.push_back(m_states[maximum.second.first].m_c);
            maximum = table[(unsigned)i][maximum.second.first][maximum.second.second];
        }
    }

#ifdef GET_BEST_PROGRESSION_DEBUG
    cout << "Output : " << result.size() << endl;
    for(auto r : result)
    {
         cout<<r.first; 
        cout<<" : "<<r.second<<endl;
    }
#endif

    return result;
}


template<typename Obs>
void HMM_backend<Obs>::forwardProcedure(const std::vector<Obs> & obsSeq)
{
#ifdef FORWARD_PROCEDURE_DEBUG
    cout << "forwardProcedure function, from Markov.cpp" << endl;
    cout << "Input : " << endl;
    for(const auto& o : obsSeq){
        cout<<o<<endl;
    }
#endif
    m_alpha = vector<vector<Proba>> (obsSeq.size(), vector<Proba> (m_states.size()));

    //we get the ids corresponding to the observations in the given sequence
    vector<ObsId> ids(obsSeq.size());
    transform(obsSeq.begin(),obsSeq.end(),ids.begin(), [this](const Obs & o){return o.getClosestObs(m_obsSet);});
    


    for(unsigned i = 0;i<m_states.size();i++){
        m_alpha[0][i] = m_pi[i] * m_observation[i][ids[0]];
    }
    for(unsigned t = 0;t<obsSeq.size()-1;t++){
        for(unsigned j = 0;j<m_states.size();j++){
            Proba sum = 0;
            for(unsigned i = 0;i<m_states.size();i++){
                sum += m_alpha[t][i] * m_transition[i][j];
            }
            m_alpha[t+1][j] = m_observation[j][ids[t+1]] * sum;
        }
    }
#ifdef FORWARD_PROCEDURE_DEBUG
    cout << "Output : "  << endl;
    for(const auto& r : m_alpha){
        for(const auto& e : r){
            cout<<e<<endl;
        }
    }
#endif
}

template<typename Obs>
void HMM_backend<Obs>::backwardProcedure(const std::vector<Obs> & obsSeq)
{
#ifdef BACKWARD_PROCEDURE_DEBUG
    cout << "backwardProcedure function, from Markov.cpp" << endl;
    cout << "Input : " << endl;
    for(const auto& o : obsSeq){
        cout<<o<<endl;
    }
#endif
    m_beta = vector<vector<Proba>> (obsSeq.size(), vector<Proba> (m_states.size()));

    //we get the ids corresponding to the observations in the given sequence
    vector<ObsId> ids(obsSeq.size());
    transform(obsSeq.begin(),obsSeq.end(),ids.begin(), [this](const Obs & o){return o.getClosestObs(m_obsSet);});
    
    for(unsigned i = 0;i<m_states.size();i++){
        m_beta[obsSeq.size()-1][i] = m_pi[i] * m_observation[i][ids[obsSeq.size()-1]]; 
    }
    for(int t = obsSeq.size()-2;t>=0;t--){
        for(unsigned i = 0;i<m_states.size();i++){
            m_beta[t][i] = 0;
            for(unsigned j = 0;j<m_states.size();j++){
                m_beta[t][i] += m_beta[t+1][j] * m_transition[i][j] * m_observation[j][ids[t+1]]; 
            }
        }
    }
#ifdef BACKWARD_PROCEDURE_DEBUG
    cout << "Output : "  << endl;
    for(const auto& r : m_beta){
        for(const auto& e : r){
            cout<<e<<endl;
        }
    }
#endif
}



template<typename Obs>
void HMM_backend<Obs>::updateProcedure(const std::vector<Obs> & obsSeq)
{
#ifdef UPDATE_PROCEDURE_DEBUG
    cout << "updateProcedure function, from Markov.cpp" << endl;
    cout << "Input : " << endl;
    for(const auto& o : obsSeq){
        cout<<o<<endl;
    }
#endif
    vector<vector<Proba>> gamma = vector<vector<Proba>> (obsSeq.size(), vector<Proba> (m_states.size()));

    //we get the ids corresponding to the observations in the given sequence
    vector<ObsId> ids(obsSeq.size());
    transform(obsSeq.begin(),obsSeq.end(),ids.begin(), [this](const Obs & o){return o.getClosestObs(m_obsSet);});
    /*    for(const auto & o : obsSeq){
        ids.push_back(o.getClosestObs(m_obsSet));
        }*/

    
    vector<vector<vector<Proba>>> xi = vector<vector<vector<Proba>>>(obsSeq.size(), vector<vector<Proba>> (m_states.size(), vector<Proba> (m_states.size())));

    
    for(unsigned t = 0;t<obsSeq.size();t++){
        Proba sum = 0;
        for(unsigned k = 0;k<m_states.size();k++){
            sum += m_alpha[t][k]*m_beta[t][k];
        }
        for(unsigned i = 0;i<m_states.size();i++){
            gamma[t][i] = (m_alpha[t][i]*m_beta[t][i]) / sum;
            if(t!=obsSeq.size()-1){
                for(unsigned j = 0;j<m_states.size();j++){
                    xi[t][i][j] =  (m_alpha[t][i] * m_beta[t+1][j] * m_transition[i][j] * m_observation[j][ids[t+1]]) / sum;
                }
            }
        }
    }
                                                            
    
    for(unsigned i = 0;i<m_states.size();i++){
        m_pi[i] = m_alpha[0][i];
    }

    for(unsigned i = 0;i<m_states.size();i++){
        Proba gammaSum = 0;
        for(unsigned t = 0;t<obsSeq.size()-1;t++){
            gammaSum += gamma[t][i];
        }
        for(unsigned j = 0;j<m_states.size();j++){
            Proba xiSum = 0;
            for(unsigned t = 0;t<obsSeq.size()-1;t++){
                xiSum += xi[t][i][j];
            }
            m_transition[i][j] = gammaSum / xiSum;
        }
        for(unsigned k = 0;k<m_obsSet.size(); k++){
            Proba gammaSumBis = 0;
            for(unsigned t = 0;t<obsSeq.size()-1;t++){
                gammaSumBis += ((ids[t] == k) ? gamma[t][i] : 0);
            }
            m_observation[i][k] = gammaSumBis / gammaSum;
        }
    }
    
#ifdef UPDATE_PROCEDURE_DEBUG
    cout << "Output : "  << endl;
#endif
}
template<typename Obs>
unsigned HMM_backend<Obs>::getMaxProgressionsNbr() const
{
    unsigned res = 0;

    for(const auto &c : m_states)
    {
        for(const auto &cprime : m_states)
        {
            if (m_transition[c][cprime] > 0)
            { res++; }
        }
    }

    return res;
}


template<typename Obs>
void HMM_backend<Obs>::learn_unsupervised(Database& db,const std::string& style)
{
    std::vector<Data> entries = db.readAllEntries(style);
    generateObsSet(entries);
    for(const auto& e : entries){
        Melody M = e.getMelody();
        std::vector<Obs> observations;
        observations.reserve(M.size());
        for(const auto& mes : M){
            observations.push_back(Obs(mes,0.2).getClosestObs(m_obsSet));
        }
        forwardProcedure(observations);
        backwardProcedure(observations);
        updateProcedure(observations);
    }
}

template<typename Obs>
void HMM_backend<Obs>::generateObsSet(const std::vector<Data>& entries)
{
    for(const auto& e : entries){
        Melody M = e.getMelody();
        for(const auto& mes : M){
            Obs o(mes,0.2);
            bool dejaVu = false;
            for(const auto& known : m_obsSet){
                if(o==known){
                    dejaVu = true;
                    break;
                }
            }
            if(!dejaVu){
                m_obsSet.push_back(o);
            }
        }
    }
    for(unsigned i=0;i<m_observation.size();i++){
        m_observation[i] = std::move(std::vector<Proba>(m_obsSet.size(),0));
    }
}


template<typename Obs>
void HMM_backend<Obs>::learn(Database& db,const std::string& style)
{
    std::vector<Data> entries = db.readAllEntries(style);
    generateObsSet(entries);
    vector<int> seenState(m_states.size(),0);
    vector<int> seenObs(m_states.size(),0);
    vector<int> debCount(m_states.size(),0);

    if(verbose_flag){
        std::cout << "taille de m_obsSet : " << m_obsSet.size() << std::endl;
        std::cout << "taille de seenObs : " << seenObs.size() << std::endl;
    }


    for(unsigned i=0;i<m_transition.size();i++){
        for(unsigned j=0;j<m_transition[i].size();j++){
            m_transition[i][j]=0;
        }
    }
    for(unsigned i=0;i<m_observation.size();i++){
        for(unsigned j=0;j<m_observation[i].size();j++){
            m_observation[i][j]=0;
        }
    }

    for(const auto& e : entries){
        Melody M = e.getMelody();
        ChordProgression C = e.getChords();
        std::vector<unsigned> observations;
        observations.reserve(M.size());
        for(const auto& mes : M){
            observations.push_back(Obs(mes,0.2).getClosestObs(m_obsSet));
        }
        std::vector<unsigned> hiddenStates;
        hiddenStates.reserve(C.size());
        unsigned pos = 0;
        for(const auto& chord : C){
            unsigned found = 0;
            bool ok = false;
            for(const auto& st : m_states){
                if(st.m_position==pos+1&&st.m_c==chord){
                    found = st;
                    ok = true;
                    break;
                }
            }
            if(!ok){
                throw std::runtime_error("State not found");
            }
            hiddenStates.push_back(found);
            pos++;
            pos%=4;
        }
        if(verbose_flag){
            std::cout << "name : " << e.getName()<< std::endl;
            std::cout << "accord : " << C << std::endl;
            std::cout << "measure : " << M << std::endl;
        }
        assert(hiddenStates.size()==observations.size());
        debCount[hiddenStates[0]]++;

        for(unsigned i=0;i<hiddenStates.size();i++){
            if(i!=hiddenStates.size()-1){
                m_transition[hiddenStates[i]][hiddenStates[i+1]]++;
                seenState[hiddenStates[i]]++;
            }
            m_observation[hiddenStates[i]][observations[i]]++;
            seenObs[hiddenStates[i]]++;
        }
    }

    for(unsigned i=0;i<m_transition.size();i++){
        if(seenState[i]>0){
            for(unsigned j=0;j<m_transition[i].size();j++){
                m_transition[i][j] /= Proba(seenState[i]);
            }
        }
        else {
            for(unsigned j=0;j<m_transition[i].size();j++){
                m_transition[i][j] = (Proba(1))/Proba(m_transition[i].size());
            }
        }
    }
    for(unsigned i=0;i<m_observation.size();i++){
        if(seenObs[i]>0){
            for(unsigned j=0;j<m_observation[i].size();j++){
                m_observation[i][j]/=Proba(seenObs[i]);
            }
        }
        else {
            for(unsigned j=0;j<m_observation[i].size();j++){
                m_observation[i][j] =  (Proba(1))/Proba(m_observation[i].size());
            }
        }
    }

    for(unsigned i=0;i<m_states.size();i++){
        m_pi[i]=Proba(debCount[i])/Proba(entries.size());
    }
}
