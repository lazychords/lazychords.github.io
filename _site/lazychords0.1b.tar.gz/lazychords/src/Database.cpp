#include "Database.hpp"
#include <boost/filesystem/fstream.hpp>
using namespace boost::filesystem;


/*! Remove a name form the name list (by side effect)
 *\param name the name of the data.
 *\param names the string of the names.
 *\return true if and only if the deletion was successfull.
 */
bool deleteFromList(const std::string& name, std::string& names);
bool isInList(const std::string& name, const std::string& names) __attribute__((const));

/*! readData extract a Data from the list. There's a side-effect on the DataList
 *\param DataList the list of the Data.
 *\return the first Data of this list.
 */
Data readData(std::string &DataList);


Data::Data(std::string n,ChordProgression c,Melody m):m_Name(n),m_Chords(c),m_melody(m){}
Data::Data(std::string n,std::string fileMelody , std::string fileChords):m_Name(n),m_Chords(readChordProgression(getFile(fileChords))),m_melody(readMelody(getFile(fileMelody))){}

//Data::Data(){};

std::string Data::getName() const
{return m_Name;}

ChordProgression Data::getChords() const
{return m_Chords;}

Melody Data::getMelody() const
{return m_melody;}

void Data::setName(std::string n)
{m_Name=n;}

void Data::setChords(ChordProgression c)
{m_Chords=c;}

void Data::setMelody(Melody m)
{m_melody=m;}

std::ostream& operator <<(std::ostream& o, Data d){
    o<<"D : ";
    o<<d.getName();
    o<<"\n";
    o<<d.getChords();
    o<<"\n";
    o<<d.getMelody();
    o<<"\n";
    return o;
}



//returns true if the deletion was succesfull.
bool deleteFromList(const std::string& name, std::string &names){
    std::string nameread;
    std::string changedstring="";
    std::stringstream ss;
    ss<<names;
    bool rep=false;
    while (std::getline(ss,nameread,char(' '))){
        if (nameread==name){
            rep=true;
        }else{
            if (changedstring =="") {
                changedstring=nameread;
            } else {
                changedstring=changedstring+" "+nameread;
            }
        }
    }
    names=changedstring;
    return rep;
}

bool isInList(const std::string& name,const std::string &names)
{
    std::string nameread;
    std::stringstream ss;
    ss<<names;
    while (std::getline(ss,nameread,char(' '))){
        if (nameread==name){
            return true;

        }
    }
    return false;
}


Database::Style::Style() : m_name(),m_inFile(nullptr),m_path()
{}
Database::Style::Style(const boost::filesystem::path& p,const std::string& name) : m_name(name),m_inFile(new fstream(p,std::ios::in|std::ios::out)),m_path(p)
{
    if(!m_inFile){
        throw std::runtime_error("Invalid style (file cannot be read)");
    }
}


Database::Style::~Style()
{
    if(m_inFile){
        m_inFile->close();
    }
}


void Database::Style::setContent(const std::string& str){
    if(m_inFile){
        m_inFile->close();
        m_inFile = std::unique_ptr<std::fstream>(new fstream(m_path,std::ios::trunc|std::ios::out));
        (*m_inFile)<<str;
        m_inFile->close();
        m_inFile = std::unique_ptr<std::fstream>(new fstream(m_path,std::ios::in|std::ios::out));
    }else{
        throw std::runtime_error("File not valid");
    }
}


Database::Database() : m_styles()
{
    if(verbose_flag){
        std::cout<<"Loading database..."<<std::endl;
    }
    using namespace boost::filesystem;
    auto d=path("./.db/");
    int tot = 0;
    if(exists(d)){
        directory_iterator end_itr; // default construction yields past-the-end
        for(directory_iterator itr(d); itr != end_itr; ++itr ){
            if(!is_directory(itr->status())){
                std::string fname = itr->path().filename().string();
                if(fname.substr(fname.length()-3)==".db"){
                    // m_styles[fname.substr(0,fname.length()-3)] = std::move(Style(itr->path().string(),fname.substr(0,fname.length()-3)));
                    m_styles.emplace(fname.substr(0,fname.length()-3),Style(itr->path().string(),fname.substr(0,fname.length()-3)));
                    tot++;
                }
            }
        }
    }else{
        if(verbose_flag){
            std::cout<<"Database doesn't seem to exist. Creating..."<<std::endl;
        }
        create_directory(d);
    }
    if(verbose_flag){
        std::cout<<"Loaded "<<tot<<" styles"<<std::endl;
    }
}

void Database::addEntry(const std::string& styleName, const Data& e)
{
    if(m_styles.count(styleName)==0){ //create style if not existing
        if(verbose_flag){
            std::cout<<"The requested style("<<styleName<<") doesn't exist, creating it"<<std::endl;
        }
        auto d=path("./.db/"+styleName+".db");
        ofstream file(d);
        if(file){
            file<<std::endl;
            file.close();
        }else{
            throw std::runtime_error("Error creating the file for style "+styleName);
        }
        m_styles.emplace(styleName,Style(d,styleName));
    }
    //read the existing file
    m_styles[styleName].m_inFile->clear();
    m_styles[styleName].m_inFile->seekg (0, m_styles[styleName].m_inFile->beg);//goto beginning
    std::string names="";
    std::string s="",ligne;

    std::getline(*(m_styles[styleName].m_inFile),names);
    std::cout<<"NAMES "<<names<<std::endl;
    while (getline(*(m_styles[styleName].m_inFile),ligne)){
        s=s+ligne+"\n";
    }
    m_styles[styleName].m_inFile->clear();
    m_styles[styleName].m_inFile->exceptions(std::fstream::failbit | std::fstream::badbit );
    //check if the given name already exists
    if (isInList(e.getName(), names)){
        throw std::runtime_error("Name "+e.getName()+" already used");
    }

    m_styles[styleName].m_inFile->seekp(0,m_styles[styleName].m_inFile->beg);//goto beginning
    (*m_styles[styleName].m_inFile)<<e.getName()<<" "<<names<<"\n"<<s<<e;
}


void Database::addEntry(std::string style, std::string fileMelody , std::string fileChords, std::string name)
{

    try{
        addEntry(style,Data(name,fileMelody,fileChords));
    }
    catch(const std::exception& e){
        std::cerr<<"There was an error while creating the entry :"<<std::endl<<e.what()<<std::endl;
        return;
    }
    catch(...){
        std::cerr<<"There was an unknown error while creating the entry."<<std::endl;
    }
}

std::vector<std::string> Database::getAvailableStyles() const
{
    std::vector<std::string> result;
    transform(m_styles.begin(),m_styles.end(),result.begin(),[](const std::pair<const std::string,Style>& elem){return elem.first;});
    return result;
}

Data readData(std::string &DataList){
    if (DataList==""){
        throw std::runtime_error("No more data to read.\n");
    }
    std::stringstream ss;
    ss<<DataList;
    std::string name;
    getline (ss,name);
    name.erase (0,4);
    std::string chords;
    getline (ss,chords);
    ChordProgression C=readChordProgression(chords);
    std::string s,melody="";
    for (int i=0; i<10 ; i++){
        getline (ss,s);
        melody= melody + s+"\n";
        if(s.size()<2||s[1]!=':'){
            break;
        }
    }
    Melody m=readMelody(melody);
    Data d=Data(name,C,m);
    DataList = ss.str();
    DataList.erase(0,name.length()+5);
    DataList.erase(0,chords.length()+1);
    DataList.erase(0,melody.length());
    return d;
}

std::vector<std::string> Database::listEntries(const std::string& style)
{
    if(m_styles.count(style)==0){
        if(verbose_flag){
            std::cout<<"Style not known"<<std::endl;
        }
        return std::vector<std::string>();
    }else{
        if(verbose_flag){
            std::cout<<"Style known"<<std::endl;
        }
    }
    //read the existing file.
    std::string names="";
    m_styles[style].m_inFile->clear();
    m_styles[style].m_inFile->seekg (0, m_styles[style].m_inFile->beg);//goto beginning
    getline(*(m_styles[style].m_inFile),names);
    //Print the list of the file
    std::stringstream ss;
    std::string Name;
    std::vector<std::string> list;
    ss<<names;
    while (getline (ss, Name ,char (' '))){
        list.push_back(Name);
    }
    return list;
}

void Database::deleteEntry(std::string style, std::string name)
{
    if(m_styles.count(style)==0){
        throw std::runtime_error("The style '"+style+"' doesn't exists");
    }
    std::string names="";
    std::string s="";
    m_styles[style].m_inFile->clear();
    m_styles[style].m_inFile->seekg (0, m_styles[style].m_inFile->beg);//goto beginning
    getline(*(m_styles[style].m_inFile),names);
    std::string ligne;
    while (getline(*(m_styles[style].m_inFile),ligne)){
        s=s+ligne+"\n";
    }
    m_styles[style].m_inFile->clear();
    //check if there is a file with this name and rewrite the file.
    if (!deleteFromList(name, names)){
        throw std::runtime_error("No entry found under the name '"+name+"'.\n");
    }else{
        std::stringstream ss;
        ss<<names<<"\n";
        while(1){
            try{
                Data Dataread = readData(s);
                if (Dataread.getName()!=name){
                    ss<<Dataread;
                }
            }
            catch(...){
                m_styles[style].setContent(ss.str());
                break;
            }
        }
    }
}

Data Database::getEntry(const std::string& name,const std::string& style) const
{
    //read the existing file.
   if(m_styles.count(style)==0){
        throw std::runtime_error("The file "+style+" can not be opened.\n");
   }
   m_styles.at(style).m_inFile->clear();
   m_styles.at(style).m_inFile->seekg (0, m_styles.at(style).m_inFile->beg);//goto beginning
   std::string names="";
   std::string s="";
   getline(*(m_styles.at(style).m_inFile),names);
   std::string ligne;
   while (getline(*(m_styles.at(style).m_inFile),ligne)){
       s=s+ligne+"\n";
   }

   //check if there is a file with this name and rewrite the file.
   if (!isInList(name, names)){
       throw std::runtime_error("This entry doesn't exist.\n");
   }
   while(1){
       try{
           Data read = readData(s);
           if (read.getName()==name){
               return read;
           }
       }
       catch(...){
           break;
       }
   }
   
   throw std::runtime_error("Data not found.\n");
   return Data("",ChordProgression(),Melody()); //shouldn't happen
}

std::vector<Data> Database::readAllEntries(const std::string& style) 
{
    std::vector<Data> answer;
    //read the existing file.
   std::string names="";
   std::string s="";
   if(m_styles.count(style)==0){
        throw std::runtime_error("The file "+style+" can not be opened.\n");
   }
   m_styles.at(style).m_inFile->clear();
   m_styles[style].m_inFile->seekg (0, m_styles[style].m_inFile->beg);//goto beginning
   getline(*(m_styles[style].m_inFile),names);
   std::string ligne;
   while (getline(*(m_styles[style].m_inFile),ligne)){
       s=s+ligne+"\n";
   }
   
   while(1){
       try{
           Data Dataread = readData(s);
           answer.push_back(Dataread);
       }
       catch(...){
           break;
       }
   }
   return answer;
}
