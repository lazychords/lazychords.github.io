#include <iostream>
#include "MusicRules.hpp"
#include <sstream>
#include "Music.hpp"
#include "Track.hpp"
#include <fstream>
#include "Utilities.hpp"
#ifndef NOT_USE_ML
    #include "Database.hpp"
    #include "Markov.hpp"
    #include "Observation.hpp"
    using MlModel = HMM_backend<ObsPresenceStats>;
    int verbose_flag=0;
#endif

using namespace std;


int main()
{
    try
    {
        #ifndef NOT_USE_ML
        Database Db;
        MlModel ML;
        ML.learn(Db,"pop");
        #endif
        string ruleFile = "./default.rules";
        vector<string> ruleNames = { "Default1", "Default2", "Default3", "Default4", "Default5"};
        vector<string> simpleChords = {"C", "F", "G", "Am"};
        vector<string> melodyFiles;

        melodyFiles.push_back("examples/Poireaux.abc");
        melodyFiles.push_back("examples/Melodies/DavidGuetta_WhenLoveTakesOver_Refrain_Melody.abc");
        melodyFiles.push_back("examples/Melodies/MGMT_Kids_Melody.abc");

        melodyFiles.push_back("examples/Melodies/MickaelJackson_BeatIt_Verse_Melody.abc");
        melodyFiles.push_back("examples/Melodies/TheBeatles_LetItBe_Refrain_Melody.abc");
        melodyFiles.push_back("examples/Melodies/TheBeatles_LetItBe_Verse_Melody.abc");
        melodyFiles.push_back("examples/Melodies/Timbaland_Apologize_Refrain_Melody.abc");
        melodyFiles.push_back("examples/Melodies/Train_HeySoulSister_Melody.abc");
        melodyFiles.push_back("examples/cooleys-1.abc");
        melodyFiles.push_back("examples/finnish-1.abc");
        SongPlayer player;

        std::string tmp;
        for (auto& mf : melodyFiles)
        {
            Melody m;
            m = readMelody(getFile(mf));
            #ifdef NOT_USE_ML
            MachineLearningOutput ml ;//= getExhaustiveChordProgression(simpleChords, m.size());
            #else
            MachineLearningOutput ml = ML.getBestProgressions(m.transpose(Key(NoteName::C,NoteName::C)),10);
            #endif
            cout << "Testing "<< mf << "...\n";
            /*ChordProgression resultat = getBestChordProgression(ruleFile, ruleNames, ml, m, 0);
              cout << "Best Chord Progression found is : "<<resultat << endl;*/
            auto resultat = getBestChordProgression(ruleFile, ruleNames, ml, m, 1);
            cout << "Best Chord Progression found is : "<<resultat << endl;
            std::cin>>tmp;
            /*if(player)
                while(!player.isFinished());*/

            player.setSong(m, resultat);
            player.setChordVolume(0.5);
            //player.setBPM(160);
            player.play();
            player.setRepeat(true);
            //if(simpleChords.size()<4)

        }
        std::cout<<"Enter any string to continue\n";
        cin>>tmp;
    }
    catch(const std::exception& e)
    {
        std::cout<<"EXCEPTION : "<<e.what()<<"\n";
    }
    catch(...)
    {
        std::cout<<"Unknown EXCEPTION : \n";
    }

    return 0;
}
