#ifndef DATABASE_HPP_INCLUDED
#define DATABASE_HPP_INCLUDED
#include "Music.hpp"
#include "Utilities.hpp"
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <memory>
#include "boost/filesystem.hpp"
#include <boost/filesystem/fstream.hpp>


extern int verbose_flag;
/**
 * This class is used to store a data in the database.
 * The Chords and the Melody are exactly what their name says.
 * The name is used to find a specific data in the database
 * In fact it will be usefull if and only if there is a mistake.
 * A mistake is storing a pop-music data in jazz.
 */

class Data {
public:
    /**@brief constructor for Data
     * @param name name of the entry
     * @param c chord progression 
     * @param m melody
     */
    Data(std::string name,ChordProgression c,Melody m);
    
    /** @brief constructor for Data from files
     * 
     * 
     * @param name name of the entry
     * @param fileMelody file where the melody is stored
     * @param fileChords file where the chordProgression is stored
     * @throw std::runtime_error if something want wrong when reading/parsing the given files
     */
    Data(std::string name,std::string fileMelody , std::string fileChords);
    //  Data();
    //Getteur
    /*! Returns the name of the data
     *
     *\return The name of the data
     */
    std::string getName() const __attribute__((pure));
    /*! Returns the Chords
     *
     *\return The Chords
     */
    ChordProgression getChords() const __attribute__((pure));
    /*! Returns the melody
     *
     *\return The melody
     */
    Melody getMelody() const __attribute__((pure));

    //Setteur
    /*! @brief Sets the name of the data.
     *\param k The Name of the data.
     */
    void setName(std::string d);
    /*! @brief Sets the chords.
     *\param k The Chords.
     */
    void setChords(ChordProgression c);
    /*! @brief Sets the melody.
     *\param k The melody.
     */
    void setMelody(Melody m);

private:
    std::string m_Name;
    ChordProgression m_Chords;
    Melody m_melody;
};



/**
 *@brief output operator for Data.
 *The format is capital letters for the NoteName
 *@param o the stream to write in
 *@param n the NoteName to write
 *@return o
 */
std::ostream& operator <<(std::ostream& o, Data d);

/**
 *@brief input operator for NoteName
 *The format is capital or small letters for the NoteName
 *@param i the stream to read from
 *@param n the NoteName to write in
 *@throw std::domain_error if not a NoteName
 *@return i
 */
//std::istream& operator >>(std::istream& i, Data d);


class Database
{
public:

    class Style
    {
        friend class Database;
    public:
        ~Style();
        Style(Style&& o) = default;
        Style();
        Style& operator=(Database::Style&& o) = default;
        /**@brief constructor of a given style, based on its name 
         * 
         * @throw std::runtime_error if the corresponding file is not readable.
         * @param name 
         */
        Style(const boost::filesystem::path& p, const std::string& name);

        /**Delete the content of the file, and replace it by the string 
         * @param str inteded content
         */
        void setContent(const std::string& str);
    private:
        
        Style(const Style&) = delete;
        Style& operator=(const Database::Style&) = delete;

        std::ifstream& file() __attribute__((pure));
        
        std::string m_name;
        std::unique_ptr<std::fstream> m_inFile;
        boost::filesystem::path m_path;
    };

    /**@brief Constructor of a db 
     * It scans the directory looking for available styles
     * @param style the name of the style we want to deal with
     */
    Database();

    /**@brief Add given entry to the given style
     * 
     * 
     * @param style where the entry should be added
     * @param e the entry itself
     * @throw std::runtime_error in case of IO error
     */
    void addEntry(const std::string& style,const Data& e);
    
    /*! add create and add a data to a file
     *\param style the style where the entry should be added
     *\param fileMelody the file where the melody is stored
     *\param fileChords the file where the chord progression is stored
     *\param name the name of the entry.
     *@throw std::runtime_error
     */
    void addEntry(std::string style, std::string fileMelody , std::string fileChords , std::string name);



    /** @brief get the name of the entries stored under the given style 
     * @param style name of the style
     * 
     * @return a list of name of the entries
     */
    std::vector<std::string> listEntries(const std::string& style);


    /*! Retrieve an entry given its name.
     *\param style the name of the style of music.
     *\param dataname the name of the entry we want to retrieve.
     *\return the entry which has this name.
     */
    Data getEntry(const std::string& name,const std::string& style)const;



    /*! Retrieve all the entries for the given style
     *\param style name of the style we want to retrieve.
     *\return the vector of the Data entries.
     */
    std::vector<Data> readAllEntries(const std::string& style);

    /**\brief returns the name of the known styles
     * @return vector of string of the name of ths styles
     */
    std::vector<std::string> getAvailableStyles() const;

    /** @brief delete an entry in the given style
     * 
     * 
     * @param style Name of the style
     * @param name Name of the entry to delete
     */
    void deleteEntry(std::string style,std::string name);

protected:


private:
    
    std::map<std::string,Style> m_styles; ///< List of the styles and the corresponding object
};


#endif
