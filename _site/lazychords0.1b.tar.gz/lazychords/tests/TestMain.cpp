#define CATCH_CONFIG_MAIN
#include "catch.hpp"

/* This file is intended to remain empty.
Write your tests in a file with a name corresponding to what you're testing */
